# exclude-categories-from-rss

Note:  This plugin requires editing php files.  If you are not comfortable doing this, please stop now and consult a developer.  I offer no support for this plugin.

Use:

Download zip file

Open the exclude-categories-from-rss.php file into a text editor.

Edit line 14 with your categories inside the array( ) section.

Activate Plugin from WP plugins page.


